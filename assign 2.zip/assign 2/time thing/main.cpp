#include <iostream>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <sys/ipc.h>
using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    void *shared_memory;
    void *shared;
    struct timeval s;
    gettimeofday(&s,0);
    int shmid;
    shmid = shmget((key_t)2345,1024,0666|IPC_CREAT);
    shared_memory = &s.tv_sec;
    shared = &s.tv_usec;
    cout<<(long)shared_memory;
    return 0;
}
