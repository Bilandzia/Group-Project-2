#include <iostream>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <sys/ipc.h>
using namespace std;

int main()
{
    key_t k = ftok("shmfile",65);
    int shmid = shmget(k,1024,0666|IPC_CREAT);
    struct timeval s;
    struct timeval e, el;
    pid_t pid;
    string please;
    cout << "Hello world!" << endl;
    char test[50];
    int i = 0;
    cin>>please;
    fgets(test,50,stdin);//reads input from user

    //gettimeofday(&s,0);
    //cout<<s.tv_sec<<endl;
    char* temptest= test;
    char* thisone[sizeof(test)+1];
    char* l;
    //string please = temptest;// creates a string of the user input before strtok alters it
    if(please.find("./time")!= std::string::npos)
    {
        //char* arg0 = strtok(temptest, " ");
        //char* arg1 = strtok(NULL," ");
        //char *command = arg0;
        //thisone[0] = arg0;
        //thisone[1] = arg1;
        //thisone[2] = NULL;
        l = strtok(temptest, " ");
        while(l != NULL)
        {
        thisone[i] = l;
        l = strtok(NULL, " ");
        i++;
        }
        thisone[i] = NULL;
        gettimeofday(&e,0);
        pid = fork();
        if(pid < 0)
        {
            exit(-1);// this shouldn't happen
        }
        else if(pid == 0)//child process
        {
        //system(arg1);
        gettimeofday(&e,0);
        void* shared_memory;
        void* shared;
        int shmid;
        shmid= shmget((key_t)2345,1024,0666);
        shared_memory = shmat(shmid,NULL,0);
        //cout<<endl<<endl<<endl<<endl<<thisone[0]<<endl<<thisone[1]<<endl<<endl<<endl<<endl<<"child function"<<endl<<endl<<endl; //just testing values
        execvp(thisone[0],thisone);
        s.tv_sec = (long)shared_memory;

        }
        else//parent function
        {
        wait(NULL);
        cout<<"This is the parent function"<<endl<<endl<<endl;
        //execvp(thisone[0],thisone);
        float elapsed = e.tv_sec-s.tv_sec;
        timersub(&e,&s,&el);
        cout<<"this took: "<<e.tv_sec<<" - "<<s.tv_sec<<" = "<<el.tv_sec<<" seconds"<<endl;

        }

        //cout<<"COMMAND TYPED BY USER:"<<endl<<please<<endl<<endl<<"ARGUEMENT 0: "<<arg1<<endl;
    return 0;
    }
}
